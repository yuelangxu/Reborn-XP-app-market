var tracks=[], selected=null;

var ac=null, src=null, baseBuf=null, playBuf=null;
var reversed=false;

var wantPlay=false;
var startAt=0, offset=0, rate=1, raf=0, seeking=false;

var gIn=null, gOut=null, gDry=null, gWet=null, gVol=null;
var eqLow=null, eqMid=null, eqHigh=null, convolver=null;

function $(i){return document.getElementById(i);}
function esc(s){return String(s).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&lt;").replace(/"/g,"&quot;").replace(/'/g,"&#39;");}
function stat(s){$("stat").textContent=s;}
function clamp(x,a,b){return x<a?a:(x>b?b:x);}

function ensureAC(){
  if(ac) return;
  ac=new (window.AudioContext||window.webkitAudioContext)();

  gIn=ac.createGain();
  gOut=ac.createGain();
  gDry=ac.createGain();
  gWet=ac.createGain();
  gVol=ac.createGain();

  eqLow=ac.createBiquadFilter(); eqLow.type="lowshelf"; eqLow.frequency.value=120; eqLow.gain.value=0;
  eqMid=ac.createBiquadFilter(); eqMid.type="peaking"; eqMid.frequency.value=1000; eqMid.Q.value=0.9; eqMid.gain.value=0;
  eqHigh=ac.createBiquadFilter(); eqHigh.type="highshelf"; eqHigh.frequency.value=6000; eqHigh.gain.value=0;

  convolver=ac.createConvolver();
  convolver.buffer=makeIR(1.6,2.2);

  gIn.connect(eqLow);
  eqLow.connect(eqMid);
  eqMid.connect(eqHigh);

  eqHigh.connect(gDry);
  eqHigh.connect(convolver);
  convolver.connect(gWet);

  gDry.connect(gOut);
  gWet.connect(gOut);
  gOut.connect(gVol);
  gVol.connect(ac.destination);

  setRate(parseFloat($("speed").value), true);
  setEQ();
  setMix();
  setVol(parseFloat($("vol").value));
}

function makeIR(seconds,decay){
  var r=ac.sampleRate, len=Math.floor(seconds*r);
  var ir=ac.createBuffer(2,len,r);
  var c,ch,i,t;
  for(c=0;c<2;c++){
    ch=ir.getChannelData(c);
    for(i=0;i<len;i++){
      t=i/len;
      ch[i]=(Math.random()*2-1)*Math.pow(1-t,decay);
    }
  }
  return ir;
}

function durationSec(){
  if(!baseBuf) return 0;
  return baseBuf.duration||0;
}

function fmtTime(s){
  if(!isFinite(s)||s<0) s=0;
  var m=Math.floor(s/60), r=Math.floor(s-m*60);
  return (m<10?"0":"")+m+":"+(r<10?"0":"")+r;
}

function bufferPosNow(){
  if(!baseBuf) return 0;
  var d=durationSec();
  if(!src) return clamp(offset||0,0,d);
  var t=ac.currentTime-startAt;
  return clamp((offset||0)+t*rate,0,d);
}

function forwardPosNow(){
  if(!baseBuf) return 0;
  var d=durationSec();
  var p=bufferPosNow();
  return reversed ? clamp(d-p,0,d) : clamp(p,0,d);
}

function setOffsetFromForward(sec){
  if(!baseBuf) return;
  var d=durationSec();
  sec=clamp(sec,0,d);
  offset = reversed ? (d-sec) : sec;
}

function cancelAnim(){
  if(raf){cancelAnimationFrame(raf);raf=0;}
}

function updateUI(force){
  var d=durationSec();
  if(d<=0){
    $("time").textContent="00:00 / 00:00";
    if(force) $("seek").value=0;
    return;
  }
  var f=forwardPosNow();
  if(!seeking || force) $("seek").value=clamp(f/d,0,1);
  $("time").textContent=fmtTime(f)+" / "+fmtTime(d);
}

function anim(){
  if(!src){raf=0;return;}
  updateUI(false);
  raf=requestAnimationFrame(anim);
}

function startAnim(){
  cancelAnim();
  raf=requestAnimationFrame(anim);
}

function hardStop(){
  if(src){
    try{src.onended=null;}catch(e){}
    try{src.stop(0);}catch(e){}
    try{src.disconnect();}catch(e){}
    src=null;
  }
  cancelAnim();
}

function reverseBuffer(b){
  var nb=ac.createBuffer(b.numberOfChannels,b.length,b.sampleRate);
  var ch,i,j,s,d;
  for(ch=0;ch<b.numberOfChannels;ch++){
    s=b.getChannelData(ch);
    d=nb.getChannelData(ch);
    for(i=0,j=s.length-1;i<s.length;i++,j--) d[i]=s[j];
  }
  return nb;
}

function rebuildPlayBuf(){
  if(!baseBuf) return;
  ensureAC();
  playBuf = reversed ? reverseBuffer(baseBuf) : baseBuf;
}

function makeSrc(){
  src=ac.createBufferSource();
  src.buffer=playBuf;
  src.playbackRate.value=rate;
  src.connect(gIn);
  src.onended=function(){
    if(!src) return;
    hardStop();
    var d=durationSec();
    offset = reversed ? d : 0;
    updateUI(true);
    wantPlay=false;
    stat("Stopped");
  };
}

function startPlayback(){
  if(!baseBuf){stat("No track loaded");return;}
  ensureAC();
  if(ac.state==="suspended") ac.resume();

  hardStop();
  makeSrc();

  var d=durationSec();
  offset=clamp(offset||0,0,d);
  startAt=ac.currentTime;
  src.start(0, offset);

  stat(reversed?"Playing (reverse)":"Playing");
  startAnim();
}

function ensurePlaybackMatchesIntent(){
  if(wantPlay){
    startPlayback();
  }else{
    hardStop();
    stat(reversed?"Ready (reverse)":"Ready");
    updateUI(true);
  }
}

function setRate(v, silent){
  if(!baseBuf){
    rate=v;
    $("speedv").textContent=rate.toFixed(2)+"×";
    return;
  }
  ensureAC();
  var f=forwardPosNow();
  rate=v;
  $("speedv").textContent=rate.toFixed(2)+"×";
  setOffsetFromForward(f);
  if(src) src.playbackRate.value=rate;
  if(!silent) updateUI(true);
}

function setEQ(){
  ensureAC();
  var a=parseFloat($("low").value), b=parseFloat($("mid").value), c=parseFloat($("high").value);
  eqLow.gain.value=a; eqMid.gain.value=b; eqHigh.gain.value=c;
  $("lowv").textContent=a.toFixed(1)+" dB";
  $("midv").textContent=b.toFixed(1)+" dB";
  $("highv").textContent=c.toFixed(1)+" dB";
}

function setMix(){
  ensureAC();
  var w=parseFloat($("wet").value), d=parseFloat($("dry").value);
  gWet.gain.value=w;
  gDry.gain.value=d;
  $("wetv").textContent=w.toFixed(2);
  $("dryv").textContent=d.toFixed(2);
}

function setVol(v){
  ensureAC();
  gVol.gain.value=v;
  $("volv").textContent=v.toFixed(2);
}

function setReverse(flag){
  if(!baseBuf) return;
  ensureAC();
  var f=forwardPosNow();
  reversed=!!flag;
  rebuildPlayBuf();
  setOffsetFromForward(f);
  ensurePlaybackMatchesIntent();
  updateUI(true);
}

function seekForwardTo(sec){
  if(!baseBuf) return;
  sec=clamp(sec,0,durationSec());
  setOffsetFromForward(sec);
  ensurePlaybackMatchesIntent();
  updateUI(true);
}

async function loadLibrary(){
  try{
    stat("Loading library…");
    var r=await fetch("./Music/library.json");
    var j=await r.json();
    tracks=(j&&j.tracks)?j.tracks:[];
    render();
    stat(tracks.length?"Select a track":"No tracks");
  }catch(e){
    tracks=[];
    render();
    stat("Library error");
  }
}

function render(){
  var h="", i, t, name;
  for(i=0;i<tracks.length;i++){
    t=tracks[i]||{};
    name=t.title||t.file||("Track "+(i+1));
    h+='<div class="track'+(selected===i?' sel':'')+'" data-i="'+i+'">'+esc(name)+'</div>';
  }
  $("tracks").innerHTML=h;
}

async function selectTrack(i){
  if(i<0||i>=tracks.length) return;
  selected=i;
  render();

  wantPlay=false;
  hardStop();

  offset=0;
  baseBuf=null;
  playBuf=null;
  reversed=false;

  var t=tracks[i]||{};
  $("name").textContent=t.title||t.file||"Track";
  stat("Loading track…");

  try{
    ensureAC();
    var url="./Music/"+t.file;
    var ab=await (await fetch(url)).arrayBuffer();
    baseBuf=await ac.decodeAudioData(ab.slice(0));
    playBuf=baseBuf;
    offset=0;
    stat("Ready");
    updateUI(true);
  }catch(e){
    baseBuf=null;
    playBuf=null;
    stat("Track error");
    updateUI(true);
  }
}

$("tracks").addEventListener("click", function(ev){
  var d=ev.target && ev.target.getAttribute && ev.target.getAttribute("data-i");
  if(d==null) return;
  selectTrack(parseInt(d,10));
});

$("reload").onclick=function(){ loadLibrary(); };

$("play").onclick=function(){
  if(!baseBuf){stat("No track loaded");return;}
  ensureAC();
  var f=forwardPosNow();
  reversed=false;
  rebuildPlayBuf();
  setOffsetFromForward(f);
  wantPlay=true;
  ensurePlaybackMatchesIntent();
  updateUI(true);
};

$("pause").onclick=function(){
  if(!baseBuf){wantPlay=false;hardStop();stat("Paused");updateUI(true);return;}
  wantPlay=false;
  ensurePlaybackMatchesIntent();
};

$("reverse").onclick=function(){
  if(!baseBuf){stat("No track loaded");return;}
  setReverse(!reversed);
};

$("speed").addEventListener("input", function(){
  setRate(parseFloat(this.value));
  if(wantPlay) ensurePlaybackMatchesIntent(); else updateUI(true);
});

$("low").addEventListener("input", function(){ setEQ(); });
$("mid").addEventListener("input", function(){ setEQ(); });
$("high").addEventListener("input", function(){ setEQ(); });

$("wet").addEventListener("input", function(){ setMix(); });
$("dry").addEventListener("input", function(){ setMix(); });

$("vol").addEventListener("input", function(){ setVol(parseFloat(this.value)); });

$("seek").addEventListener("input", function(){
  seeking=true;
  if(!baseBuf) return;
  var d=durationSec();
  var f=d*parseFloat(this.value);
  $("time").textContent=fmtTime(f)+" / "+fmtTime(d);
});

$("seek").addEventListener("change", function(){
  seeking=false;
  if(!baseBuf) return;
  var d=durationSec();
  var f=d*parseFloat(this.value);
  seekForwardTo(f);
});

loadLibrary();


